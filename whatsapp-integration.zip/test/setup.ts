// This file ensures TypeScript recognizes Jest globals
// No need to import anything, just having this file with setupFilesAfterEnv is enough
