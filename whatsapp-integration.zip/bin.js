#!/usr/bin/env node

// Import the main module
require('./dist/main.js'); 